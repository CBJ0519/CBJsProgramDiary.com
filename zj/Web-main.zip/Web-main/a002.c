#include<stdio.h>
int main(){
    int a,b; //宣告兩個整數a,b
    scanf("%d%d",&a,&b); //讀入a,b(測試資料)
    printf("%d\n",a+b); //輸出a+b的值
    return 0;
}
