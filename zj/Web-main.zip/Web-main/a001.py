s=input() # 將輸入內容(字串)存入s
print("hello, " + s) # 輸出"hello, " + s
