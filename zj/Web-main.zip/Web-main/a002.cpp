#include<iostream>
using namespace std;
int main(){
    int a,b; //宣告兩個整數a,b
    cin>>a>>b; //讀入a,b(測試資料)
    cout<<a+b<<"\n"; //輸出a+b的值
    return 0;
}
