a,b=map(int,input().split()) #將輸入以空白分隔，並分別轉為整數分配給a,b
print(a+b) #輸出a+b的值
